# Praia em Projeto — Protótipo
Abra `index.html` em um navegador.
O protótipo inclui página inicial, login por perfil, turmas, projetos, envio de projeto e painel básico.
O login é apenas demonstrativo: não use senhas reais. Para produção, integrar autenticação institucional e banco de dados autorizados pela escola/SEED-PR.
